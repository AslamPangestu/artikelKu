#!/usr/bin/env python
#Python Network Programing(getting host&IP)

import urllib2

url='http://elen.nurulfikri.ac.id'
rawreply = urllib2.urlopen(url).read()
print rawreply
