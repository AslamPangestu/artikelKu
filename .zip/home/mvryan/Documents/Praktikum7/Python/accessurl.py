#!/usr/bin/env python
#Python ork Programing(Access URL)

import urllib2

url = 'http://localhost'
rawreply = urllib2.urlopen(url).read()
print rawreply
