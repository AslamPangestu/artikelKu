#!/usr/bin/env python
#Python Network Programing(Access Url)

import urllib2, urllib

params = {'base': 'USD', 'symbols' : 'EUR,IDR'}
url = 'http://api.fixer.id/latest?'+urllib.urlencode(params)
rawreply = urllib2.urlopen(url).read()
reply = json.loads(rawreply)
print 'Rate'+reply['date']
print '1 USD = %0.1f IDR'%reply['rates']['IDR']
