import java.io.*;
import java.net.*;

class javServerUDP{
  public static void main(String ar[]) {
    try {
      //1. buat Socket
      DatagramSocket server = new DatagramSocket(8800);
      //definisikan paket2
      byte[] dataMasuk = new byte[1024];
      byte[] dataKirim = new byte[1024];
      //tunggu request dri client
      while(true){
        //definisi paket diterima
        DatagramPacket receivePacket = new DatagramPacket(dataMasuk,dataMasuk.length);
        //terima data
        server.receive(receivePacket);
        System.out.println("Data diterima : ");
        String pesan = new String(receivePacket.getData());
        System.out.println(pesan);
      }
    }catch (SocketException ee) {
      System.out.println("Server Gagal hidup");
    }catch (IOException io) {
      System.out.println("I/O ada yg salah");
    }
  }
}
