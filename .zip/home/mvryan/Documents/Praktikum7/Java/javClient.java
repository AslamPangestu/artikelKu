import java.net.*;
import java.io.*;
import java.util.Scanner;

class javClient{
  public static void main(String[] args) {
    try {
      //Baca argumen 1 sbg alamat
      InetAddress server = InetAddress.getByName(args[0]);
      //1 buat koneksi
      Socket connection = new Socket(server, 9900);
      //2 kirim output
      String pesan = "";
      PrintWriter output = new PrintWriter(connection.getOutputStream(),true);
      //2.1 baca dari keyboard
      Scanner masukan = new Scanner(System.in);
      System.out.println("Masukkan Pesan :");
      pesan = masukan.nextLine();
      //2.1 Kirim ke server
      output.println(pesan);
      //3 Tampilkan balasan dari server
      Scanner input = new Scanner(connection.getInputStream());
      String balasan = input.nextLine();
      System.out.println(balasan);
      //4 tutup koneksi
      connection.close();
    }
    catch (UnknownHostException uhe) {
      System.out.println("args[0] is not a valid server name or IP address");
    }
    catch (IOException ioe) {
      System.out.println("Gagal Koneksi");
    }

}
