import java.net.*;
import java.io.*;
import java.util.*;

class javClientUDP{
  public static void main(String ar[]) {
    //baca pesan dari keyboard
    Scanner masukkan = new Scanner(System.in);
    String pesan = "";
    System.out.println("Masukkan pesan : ");
    pesan = masukkan.nextLine();
    //datagram client
    DatagramSocket client = new DatagramSocket();
    //baca argumen sbg alamat (javClient localhost)
    InetAddress server = InetAddress.getByName(ar[0]);
    //definisikan paket2
    byte[] dataMasuk = new byte[1024];
    byte[] dataKirim = new byte[1024];
    //konversi string pesan jadi paket
    dataKirim = pesan.getBytes();
    //kirim data
    DatagramPacket sendPacket = new DatagramPacket(dataKirim,dataKirim.length
    ,server,8800);
    client.send(sendPacket);
    //tutup
    client.close();
  }catch (SocketException ee) {
    System.out.println("Server Gagal hidup");
  }catch (IOException io) {
    System.out.println("I/O ada yg salah");
  }
}
