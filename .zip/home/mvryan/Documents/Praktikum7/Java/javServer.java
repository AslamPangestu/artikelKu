import java.net.*;
import java.io.*;
import java.util.Scanner;

class javServer{
  public static void main(String[] arr) {
    try {
      //Langkah 1 - Definisikan Server Socket dgn port 9900
      ServerSocket agreedPort = new ServerSocket(9900,5);
      //Lankah 2 - Tunggu request dri client
      while(true){
        //accept request dri client
        Socket sesi = agreedPort.accept();
        //baca pesan dari client
        String pesan = "";
        try {
          Scanner input = new Scanner(sesi.getInputStream());
          pesan = input.nextLine();
          System.out.println("Dapat pesan dari client, isinya:\n"+pesan);
          //kirim output balasan u client
          PrintWriter output = new PrintWriter(sesi.getOutputStream(),true);
          output.println("Server>Pesan anda : "+pesan.toUpperCase())
        }
        catch (Exception ee) {
          System.out.println("Pesan Tidak terbaca");
        }
        sesi.close();
      }
    }catch (UnknownHostException ee) {
      System.out.println("Server Gagal hidup");
    }catch (IOException io) {
      System.out.println("I/O ada yg salah");
    }

  }

}
