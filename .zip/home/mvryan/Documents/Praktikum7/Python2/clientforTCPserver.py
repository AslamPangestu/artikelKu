import socket

#Setup a TCP/IP socket
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

#Connect as client to a selected server on specific port
s.connect(("127.0.0.1",17642))

#Protocol exchange - sends & receives
s.send("Hello")
while True:
    resp = s.recv(1024)
    if resp == "" : break
    print resp,

#Close the connection when completed
s.close()
print "\ndone"
