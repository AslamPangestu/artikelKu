import socket

#Server example
#Establish a TCP/IP socket
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

#Bind to TCP port no. 17642...
s.bind(("",17642))
#... and listen for anyone to contact you
#queueing up to 5 request if you get a backlog
s.listen(5)
print ("Server is up and running..")

#Server are "infinite" loops handeling request
while True:
    print "Waiting for Connection"
    #Wait for a connection
    connect, address = s.accept()
    #Receive up to 1024 bytes
    resp = (connect.recv(1024)).strip()
    #Send an Answer
    connect.send("You said '" + resp + "' to me\n")
    #Close the connection
    s.close()
    print "\ndone",address
    #And loop for/wait for another client
